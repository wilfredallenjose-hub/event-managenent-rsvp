# Event Management & RSVP System

A beginner-friendly Django project based on Project No. 12 in the internship PDF.

## Features
- Home page with upcoming events
- Event detail pages and RSVP form
- Django admin to create/edit events
- Staff-only attendee dashboard
- QR code for each RSVP and staff-only check-in page
- Celery task that emails reminders for events starting within the next 24 hours
- PostgreSQL support, with SQLite as the easy local starting option

## 1. Requirements
Install Python 3.11+ and (for the full setup) PostgreSQL and Redis. You can begin with SQLite and add PostgreSQL/Redis afterward.

## 2. Create a virtual environment
Open this folder in VS Code. In Terminal:

### Windows
```powershell
py -m venv .venv
.venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

### macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`, then activate again.

## 3. Create the database and admin account
```bash
python manage.py makemigrations events
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open:
- Website: http://127.0.0.1:8000/
- Admin: http://127.0.0.1:8000/admin/

Create an event in the admin panel. Set its start date/time to a future date. Add a location and description.

## 4. Try the RSVP flow
1. Open an event on the home page.
2. Fill in the RSVP form.
3. The confirmation page displays a QR code.
4. To see the attendee dashboard, create a staff user in Django admin (Users → select a user → enable Staff status), or create a superuser and sign in.
5. Open `/dashboard/` while signed in as staff.
6. Open a registration's check-in link from the dashboard. It requires staff login.

## 5. PostgreSQL setup
Create a PostgreSQL database and user, then edit `.env`:
```env
DB_ENGINE=postgres
POSTGRES_DB=event_rsvp
POSTGRES_USER=postgres
POSTGRES_PASSWORD=your_real_password
POSTGRES_HOST=127.0.0.1
POSTGRES_PORT=5432
```
Restart the Django server after changing `.env`. The project uses PostgreSQL when `DB_ENGINE=postgres`; otherwise it uses SQLite.

## 6. Email reminders with Celery + Redis
For local testing, the default email backend prints email content in the Django terminal. To use Celery, install and start Redis first.

Run Django in one terminal:
```bash
python manage.py runserver
```
Run the Celery worker in a second terminal:
```bash
celery -A eventsite worker --loglevel=info
```
Run Celery Beat in a third terminal:
```bash
celery -A eventsite beat --loglevel=info
```
On Windows, Celery workers may need `--pool=solo`:
```powershell
celery -A eventsite worker --pool=solo --loglevel=info
```

The scheduled task checks every 15 minutes for RSVP registrations whose event starts in the next 24 hours and sends one reminder per registration. It uses the configured Django email backend. For real delivery, configure SMTP values in `.env` and use an email provider's app password/credentials; never commit credentials to GitHub.

## 7. QR check-in
The RSVP confirmation page shows a QR code containing a check-in URL. Staff must be logged in to use it. A successful check-in marks the registration as checked in and displays a confirmation page. For a real public deployment, use HTTPS and set a strong `SECRET_KEY`.

## 8. GitHub
Do not upload `.env`, database files, or passwords. Upload the source files and `.env.example` only.

## Troubleshooting
- `ModuleNotFoundError`: activate `.venv`, then run `pip install -r requirements.txt`.
- `no such table`: run `python manage.py migrate`.
- PostgreSQL connection error: confirm PostgreSQL is running and the `.env` database credentials are correct; use SQLite first if you are just getting started.
- Reminders do not run: Redis, the Celery worker, and Celery Beat must all be running in separate terminals.
