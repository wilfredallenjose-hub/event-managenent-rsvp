from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from events import views

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", views.home, name="home"),
    path("events/", include("events.urls")),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("accounts/login/", auth_views.LoginView.as_view(template_name="registration/login.html"), name="login"),
    path("accounts/logout/", auth_views.LogoutView.as_view(), name="logout"),
]
