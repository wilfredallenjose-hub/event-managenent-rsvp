from django.urls import path
from . import views

app_name = "events"
urlpatterns = [
    path("<int:pk>/", views.event_detail, name="detail"),
    path("<int:pk>/rsvp/confirmation/<uuid:ticket_code>/", views.rsvp_confirmation, name="confirmation"),
    path("check-in/<uuid:ticket_code>/", views.check_in, name="check_in"),
]
