import uuid
from django.db import models
from django.urls import reverse
from django.utils import timezone

class Event(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    location = models.CharField(max_length=200)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField(blank=True, null=True)
    capacity = models.PositiveIntegerField(default=100)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["start_time"]

    def __str__(self):
        return self.title

    @property
    def is_upcoming(self):
        return self.start_time >= timezone.now()

    @property
    def spots_left(self):
        return max(self.capacity - self.registrations.count(), 0)

    def get_absolute_url(self):
        return reverse("events:detail", args=[self.pk])


class RSVP(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name="registrations")
    name = models.CharField(max_length=120)
    email = models.EmailField()
    ticket_code = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    registered_at = models.DateTimeField(auto_now_add=True)
    checked_in = models.BooleanField(default=False)
    checked_in_at = models.DateTimeField(blank=True, null=True)
    reminder_sent = models.BooleanField(default=False)

    class Meta:
        ordering = ["-registered_at"]
        constraints = [
            models.UniqueConstraint(fields=["event", "email"], name="unique_rsvp_per_event_email")
        ]

    def __str__(self):
        return f"{self.name} — {self.event.title}"
