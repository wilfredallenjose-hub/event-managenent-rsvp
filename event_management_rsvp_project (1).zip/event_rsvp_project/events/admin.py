from django.contrib import admin
from .models import Event, RSVP

class RSVPInline(admin.TabularInline):
    model = RSVP
    extra = 0
    readonly_fields = ("registered_at", "ticket_code", "checked_in_at", "reminder_sent")
    fields = ("name", "email", "checked_in", "registered_at", "ticket_code", "checked_in_at", "reminder_sent")

@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ("title", "start_time", "location", "capacity", "attendee_count")
    list_filter = ("start_time",)
    search_fields = ("title", "location")
    inlines = [RSVPInline]

    @admin.display(description="Attendees")
    def attendee_count(self, obj):
        return obj.registrations.count()

@admin.register(RSVP)
class RSVPAdmin(admin.ModelAdmin):
    list_display = ("name", "email", "event", "checked_in", "registered_at", "reminder_sent")
    list_filter = ("checked_in", "event", "reminder_sent")
    search_fields = ("name", "email", "event__title")
    readonly_fields = ("ticket_code", "registered_at", "checked_in_at")
