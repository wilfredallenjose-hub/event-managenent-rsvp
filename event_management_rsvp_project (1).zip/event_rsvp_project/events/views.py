import base64
from io import BytesIO
import qrcode
from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.core.mail import send_mail
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.conf import settings
from .forms import RSVPForm
from .models import Event, RSVP

def home(request):
    events = Event.objects.filter(start_time__gte=timezone.now())
    return render(request, "events/home.html", {"events": events})

def event_detail(request, pk):
    event = get_object_or_404(Event, pk=pk)
    form = RSVPForm(request.POST or None, event=event)
    if request.method == "POST":
        if not event.is_upcoming:
            messages.error(request, "RSVP is closed because this event has already started.")
        elif event.spots_left <= 0:
            messages.error(request, "Sorry, this event is full.")
        elif form.is_valid():
            rsvp = form.save(commit=False)
            rsvp.event = event
            rsvp.save()
            try:
                send_mail(
                    subject=f"RSVP confirmed: {event.title}",
                    message=f"Hello {rsvp.name},\n\nYour RSVP for {event.title} is confirmed.\nDate: {event.start_time:%d %b %Y, %I:%M %p}\nLocation: {event.location}\n\nKeep your QR code ready for check-in.",
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    recipient_list=[rsvp.email],
                    fail_silently=True,
                )
            except Exception:
                pass
            return redirect("events:confirmation", pk=event.pk, ticket_code=rsvp.ticket_code)
    return render(request, "events/detail.html", {"event": event, "form": form})

def rsvp_confirmation(request, pk, ticket_code):
    rsvp = get_object_or_404(RSVP, event_id=pk, ticket_code=ticket_code)
    checkin_url = request.build_absolute_uri(
        f"/events/check-in/{rsvp.ticket_code}/"
    )
    qr = qrcode.QRCode(box_size=7, border=3)
    qr.add_data(checkin_url)
    qr.make(fit=True)
    image_obj = qr.make_image(fill_color="black", back_color="white")
    buffer = BytesIO()
    image_obj.save(buffer, format="PNG")
    qr_data = base64.b64encode(buffer.getvalue()).decode("ascii")
    return render(request, "events/confirmation.html", {
        "rsvp": rsvp,
        "qr_data": qr_data,
    })

@staff_member_required
def dashboard(request):
    events = Event.objects.all().prefetch_related("registrations")
    selected_event = request.GET.get("event")
    attendees = RSVP.objects.select_related("event").order_by("-registered_at")
    if selected_event:
        attendees = attendees.filter(event_id=selected_event)
    return render(request, "events/dashboard.html", {
        "events": events,
        "attendees": attendees,
        "selected_event": selected_event or "",
    })

@staff_member_required
def check_in(request, ticket_code):
    rsvp = get_object_or_404(RSVP.objects.select_related("event"), ticket_code=ticket_code)
    if request.method == "POST" and not rsvp.checked_in:
        rsvp.checked_in = True
        rsvp.checked_in_at = timezone.now()
        rsvp.save(update_fields=["checked_in", "checked_in_at"])
        messages.success(request, f"{rsvp.name} has been checked in.")
        return redirect("events:check_in", ticket_code=rsvp.ticket_code)
    return render(request, "events/check_in.html", {"rsvp": rsvp})
