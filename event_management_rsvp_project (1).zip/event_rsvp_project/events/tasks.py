from datetime import timedelta
from celery import shared_task
from django.conf import settings
from django.core.mail import send_mail
from django.utils import timezone
from .models import RSVP

@shared_task
def send_event_reminders():
    now = timezone.now()
    soon = now + timedelta(hours=24)
    registrations = RSVP.objects.select_related("event").filter(
        reminder_sent=False,
        event__start_time__gt=now,
        event__start_time__lte=soon,
    )
    sent = 0
    for rsvp in registrations:
        event = rsvp.event
        send_mail(
            subject=f"Reminder: {event.title} is coming up",
            message=(
                f"Hello {rsvp.name},\n\nThis is a reminder that {event.title} "
                f"starts on {event.start_time:%d %b %Y at %I:%M %p}.\n"
                f"Location: {event.location}\n\nWe look forward to seeing you!"
            ),
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[rsvp.email],
            fail_silently=False,
        )
        rsvp.reminder_sent = True
        rsvp.save(update_fields=["reminder_sent"])
        sent += 1
    return f"Sent {sent} event reminder(s)."
